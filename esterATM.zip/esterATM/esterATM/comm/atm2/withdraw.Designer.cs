﻿namespace atm2
{
    partial class withdraw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            guna2Shapes1 = new Guna.UI2.WinForms.Guna2Shapes();
            btnmain = new Guna.UI2.WinForms.Guna2Button();
            btnwithdraw = new Guna.UI2.WinForms.Guna2Button();
            label5 = new Label();
            label1 = new Label();
            btn10000 = new Guna.UI2.WinForms.Guna2Button();
            btn5000 = new Guna.UI2.WinForms.Guna2Button();
            btn1000 = new Guna.UI2.WinForms.Guna2Button();
            btn200 = new Guna.UI2.WinForms.Guna2Button();
            btn500 = new Guna.UI2.WinForms.Guna2Button();
            btn100 = new Guna.UI2.WinForms.Guna2Button();
            txtboxamount = new Guna.UI2.WinForms.Guna2TextBox();
            guna2GradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Transparent;
            guna2GradientPanel1.Controls.Add(guna2Shapes1);
            guna2GradientPanel1.Controls.Add(btnmain);
            guna2GradientPanel1.Controls.Add(btnwithdraw);
            guna2GradientPanel1.Controls.Add(label5);
            guna2GradientPanel1.Controls.Add(label1);
            guna2GradientPanel1.Controls.Add(btn10000);
            guna2GradientPanel1.Controls.Add(btn5000);
            guna2GradientPanel1.Controls.Add(btn1000);
            guna2GradientPanel1.Controls.Add(btn200);
            guna2GradientPanel1.Controls.Add(btn500);
            guna2GradientPanel1.Controls.Add(btn100);
            guna2GradientPanel1.Controls.Add(txtboxamount);
            guna2GradientPanel1.CustomizableEdges = customizableEdges20;
            guna2GradientPanel1.FillColor = Color.Purple;
            guna2GradientPanel1.FillColor2 = Color.FromArgb(77, 67, 118);
            guna2GradientPanel1.ForeColor = Color.Transparent;
            guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            guna2GradientPanel1.Location = new Point(-8, -3);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges21;
            guna2GradientPanel1.Size = new Size(850, 425);
            guna2GradientPanel1.TabIndex = 3;
            // 
            // guna2Shapes1
            // 
            guna2Shapes1.BackColor = Color.Transparent;
            guna2Shapes1.BorderColor = Color.Transparent;
            guna2Shapes1.FillColor = Color.White;
            guna2Shapes1.ForeColor = Color.Transparent;
            guna2Shapes1.LineThickness = 2;
            guna2Shapes1.Location = new Point(-32, 60);
            guna2Shapes1.Margin = new Padding(3, 4, 3, 4);
            guna2Shapes1.Name = "guna2Shapes1";
            guna2Shapes1.PolygonSkip = 1;
            guna2Shapes1.Rotate = 0F;
            guna2Shapes1.RoundedEdges = customizableEdges1;
            guna2Shapes1.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            guna2Shapes1.Size = new Size(898, 17);
            guna2Shapes1.TabIndex = 64;
            guna2Shapes1.Text = "guna2Shapes1";
            guna2Shapes1.Zoom = 80;
            // 
            // btnmain
            // 
            btnmain.BackColor = Color.Transparent;
            btnmain.BorderRadius = 16;
            btnmain.CustomizableEdges = customizableEdges2;
            btnmain.DisabledState.BorderColor = Color.DarkGray;
            btnmain.DisabledState.CustomBorderColor = Color.DarkGray;
            btnmain.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnmain.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnmain.FillColor = Color.FromArgb(255, 128, 128);
            btnmain.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnmain.ForeColor = Color.Black;
            btnmain.Location = new Point(53, 287);
            btnmain.Name = "btnmain";
            btnmain.ShadowDecoration.CustomizableEdges = customizableEdges3;
            btnmain.Size = new Size(353, 45);
            btnmain.TabIndex = 59;
            btnmain.Text = "Cancel";
            btnmain.Click += btnmain_Click;
            // 
            // btnwithdraw
            // 
            btnwithdraw.BorderRadius = 16;
            btnwithdraw.CustomizableEdges = customizableEdges4;
            btnwithdraw.DisabledState.BorderColor = Color.DarkGray;
            btnwithdraw.DisabledState.CustomBorderColor = Color.DarkGray;
            btnwithdraw.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnwithdraw.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnwithdraw.FillColor = Color.FromArgb(128, 255, 128);
            btnwithdraw.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnwithdraw.ForeColor = Color.Black;
            btnwithdraw.Location = new Point(54, 236);
            btnwithdraw.Name = "btnwithdraw";
            btnwithdraw.ShadowDecoration.CustomizableEdges = customizableEdges5;
            btnwithdraw.Size = new Size(352, 45);
            btnwithdraw.TabIndex = 58;
            btnwithdraw.Text = "Continue";
            btnwithdraw.Click += btnwithdraw_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(53, 28);
            label5.Name = "label5";
            label5.Size = new Size(167, 28);
            label5.TabIndex = 57;
            label5.Text = "WITHDRAW";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(126, 116);
            label1.Name = "label1";
            label1.Size = new Size(198, 28);
            label1.TabIndex = 54;
            label1.Text = "Enter the Amount  :";
            // 
            // btn10000
            // 
            btn10000.BorderRadius = 20;
            btn10000.CustomizableEdges = customizableEdges6;
            btn10000.DisabledState.BorderColor = Color.DarkGray;
            btn10000.DisabledState.CustomBorderColor = Color.DarkGray;
            btn10000.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn10000.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn10000.FillColor = Color.Thistle;
            btn10000.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn10000.ForeColor = Color.Black;
            btn10000.HoverState.FillColor = Color.FromArgb(128, 255, 128);
            btn10000.Location = new Point(643, 272);
            btn10000.Name = "btn10000";
            btn10000.ShadowDecoration.CustomizableEdges = customizableEdges7;
            btn10000.Size = new Size(168, 72);
            btn10000.TabIndex = 53;
            btn10000.Text = "10000";
            btn10000.Click += btn10000_Click;
            // 
            // btn5000
            // 
            btn5000.BorderRadius = 20;
            btn5000.CustomizableEdges = customizableEdges8;
            btn5000.DisabledState.BorderColor = Color.DarkGray;
            btn5000.DisabledState.CustomBorderColor = Color.DarkGray;
            btn5000.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn5000.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn5000.FillColor = Color.Thistle;
            btn5000.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn5000.ForeColor = Color.Black;
            btn5000.HoverState.FillColor = Color.FromArgb(128, 255, 128);
            btn5000.Location = new Point(643, 194);
            btn5000.Name = "btn5000";
            btn5000.ShadowDecoration.CustomizableEdges = customizableEdges9;
            btn5000.Size = new Size(168, 72);
            btn5000.TabIndex = 52;
            btn5000.Text = "5000";
            btn5000.Click += btn5000_Click;
            // 
            // btn1000
            // 
            btn1000.BorderRadius = 20;
            btn1000.CustomizableEdges = customizableEdges10;
            btn1000.DisabledState.BorderColor = Color.DarkGray;
            btn1000.DisabledState.CustomBorderColor = Color.DarkGray;
            btn1000.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn1000.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn1000.FillColor = Color.Thistle;
            btn1000.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn1000.ForeColor = Color.Black;
            btn1000.HoverState.FillColor = Color.FromArgb(128, 255, 128);
            btn1000.Location = new Point(643, 116);
            btn1000.Name = "btn1000";
            btn1000.ShadowDecoration.CustomizableEdges = customizableEdges11;
            btn1000.Size = new Size(168, 72);
            btn1000.TabIndex = 49;
            btn1000.Text = "1000";
            btn1000.Click += btn1000_Click;
            // 
            // btn200
            // 
            btn200.BorderRadius = 20;
            btn200.CustomizableEdges = customizableEdges12;
            btn200.DisabledState.BorderColor = Color.DarkGray;
            btn200.DisabledState.CustomBorderColor = Color.DarkGray;
            btn200.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn200.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn200.FillColor = Color.Thistle;
            btn200.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn200.ForeColor = Color.Black;
            btn200.HoverState.FillColor = Color.FromArgb(128, 255, 128);
            btn200.Location = new Point(453, 194);
            btn200.Name = "btn200";
            btn200.ShadowDecoration.CustomizableEdges = customizableEdges13;
            btn200.Size = new Size(174, 72);
            btn200.TabIndex = 48;
            btn200.Text = "200";
            btn200.Click += btn200_Click;
            // 
            // btn500
            // 
            btn500.BorderRadius = 20;
            btn500.CustomizableEdges = customizableEdges14;
            btn500.DisabledState.BorderColor = Color.DarkGray;
            btn500.DisabledState.CustomBorderColor = Color.DarkGray;
            btn500.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn500.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn500.FillColor = Color.Thistle;
            btn500.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn500.ForeColor = Color.Black;
            btn500.HoverState.FillColor = Color.FromArgb(128, 255, 128);
            btn500.Location = new Point(453, 272);
            btn500.Name = "btn500";
            btn500.ShadowDecoration.CustomizableEdges = customizableEdges15;
            btn500.Size = new Size(172, 72);
            btn500.TabIndex = 47;
            btn500.Text = "500";
            btn500.Click += btn500_Click;
            // 
            // btn100
            // 
            btn100.BorderRadius = 20;
            btn100.CustomizableEdges = customizableEdges16;
            btn100.DisabledState.BorderColor = Color.DarkGray;
            btn100.DisabledState.CustomBorderColor = Color.DarkGray;
            btn100.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btn100.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btn100.FillColor = Color.Thistle;
            btn100.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn100.ForeColor = Color.Black;
            btn100.HoverState.FillColor = Color.FromArgb(128, 255, 128);
            btn100.Location = new Point(453, 116);
            btn100.Name = "btn100";
            btn100.ShadowDecoration.CustomizableEdges = customizableEdges17;
            btn100.Size = new Size(172, 72);
            btn100.TabIndex = 46;
            btn100.Text = "100";
            btn100.Click += btn100_Click;
            // 
            // txtboxamount
            // 
            txtboxamount.BorderRadius = 20;
            txtboxamount.CustomizableEdges = customizableEdges18;
            txtboxamount.DefaultText = "";
            txtboxamount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtboxamount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtboxamount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtboxamount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtboxamount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtboxamount.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtboxamount.ForeColor = Color.Black;
            txtboxamount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtboxamount.Location = new Point(53, 158);
            txtboxamount.Margin = new Padding(5);
            txtboxamount.Name = "txtboxamount";
            txtboxamount.PasswordChar = '\0';
            txtboxamount.PlaceholderText = "";
            txtboxamount.SelectedText = "";
            txtboxamount.ShadowDecoration.CustomizableEdges = customizableEdges19;
            txtboxamount.Size = new Size(353, 61);
            txtboxamount.TabIndex = 41;
            txtboxamount.TextAlign = HorizontalAlignment.Center;
            txtboxamount.TextChanged += txtboxamount_TextChanged;
            // 
            // withdraw
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(834, 415);
            Controls.Add(guna2GradientPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "withdraw";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "withdraw";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2TextBox txtboxamount;
        private Guna.UI2.WinForms.Guna2Button btn10000;
        private Guna.UI2.WinForms.Guna2Button btn5000;
        private Guna.UI2.WinForms.Guna2Button btn1000;
        private Guna.UI2.WinForms.Guna2Button btn200;
        private Guna.UI2.WinForms.Guna2Button btn500;
        private Guna.UI2.WinForms.Guna2Button btn100;
        private Label label1;
        private Label label5;
        private Guna.UI2.WinForms.Guna2Button btnwithdraw;
        private Guna.UI2.WinForms.Guna2Button btnmain;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes1;
    }
}