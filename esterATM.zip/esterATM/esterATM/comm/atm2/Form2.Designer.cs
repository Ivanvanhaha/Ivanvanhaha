﻿namespace atm2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            label1 = new Label();
            guna2Shapes1 = new Guna.UI2.WinForms.Guna2Shapes();
            btnbal = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            btnDeposit = new Guna.UI2.WinForms.Guna2GradientButton();
            btnWithdraw = new Guna.UI2.WinForms.Guna2GradientButton();
            label5 = new Label();
            guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            guna2GradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Transparent;
            guna2GradientPanel1.Controls.Add(label1);
            guna2GradientPanel1.Controls.Add(guna2Shapes1);
            guna2GradientPanel1.Controls.Add(btnbal);
            guna2GradientPanel1.Controls.Add(guna2GradientButton1);
            guna2GradientPanel1.Controls.Add(btnDeposit);
            guna2GradientPanel1.Controls.Add(btnWithdraw);
            guna2GradientPanel1.Controls.Add(label5);
            guna2GradientPanel1.Controls.Add(guna2Button5);
            guna2GradientPanel1.CustomizableEdges = customizableEdges12;
            guna2GradientPanel1.FillColor = Color.Purple;
            guna2GradientPanel1.FillColor2 = Color.FromArgb(77, 67, 118);
            guna2GradientPanel1.ForeColor = Color.Transparent;
            guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            guna2GradientPanel1.Location = new Point(-5, -1);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges13;
            guna2GradientPanel1.Size = new Size(833, 420);
            guna2GradientPanel1.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(56, 17);
            label1.Name = "label1";
            label1.Size = new Size(409, 28);
            label1.TabIndex = 37;
            label1.Text = "Please Select Your Transaction";
            // 
            // guna2Shapes1
            // 
            guna2Shapes1.BackColor = Color.Transparent;
            guna2Shapes1.BorderColor = Color.Transparent;
            guna2Shapes1.FillColor = Color.White;
            guna2Shapes1.ForeColor = Color.Transparent;
            guna2Shapes1.LineThickness = 2;
            guna2Shapes1.Location = new Point(-34, 49);
            guna2Shapes1.Margin = new Padding(3, 4, 3, 4);
            guna2Shapes1.Name = "guna2Shapes1";
            guna2Shapes1.PolygonSkip = 1;
            guna2Shapes1.Rotate = 0F;
            guna2Shapes1.RoundedEdges = customizableEdges1;
            guna2Shapes1.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            guna2Shapes1.Size = new Size(898, 17);
            guna2Shapes1.TabIndex = 36;
            guna2Shapes1.Text = "guna2Shapes1";
            guna2Shapes1.Zoom = 80;
            // 
            // btnbal
            // 
            btnbal.CustomizableEdges = customizableEdges2;
            btnbal.DisabledState.BorderColor = Color.DarkGray;
            btnbal.DisabledState.CustomBorderColor = Color.DarkGray;
            btnbal.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnbal.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btnbal.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnbal.FillColor = Color.Silver;
            btnbal.FillColor2 = Color.Gray;
            btnbal.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnbal.ForeColor = Color.MidnightBlue;
            btnbal.Image = (Image)resources.GetObject("btnbal.Image");
            btnbal.ImageOffset = new Point(6, 0);
            btnbal.ImageSize = new Size(60, 60);
            btnbal.Location = new Point(429, 82);
            btnbal.Margin = new Padding(3, 4, 3, 4);
            btnbal.Name = "btnbal";
            btnbal.ShadowDecoration.CustomizableEdges = customizableEdges3;
            btnbal.Size = new Size(311, 125);
            btnbal.TabIndex = 35;
            btnbal.Text = "Check Balance";
            btnbal.TextOffset = new Point(-3, 3);
            btnbal.Click += guna2GradientButton2_Click;
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.CustomizableEdges = customizableEdges4;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.FillColor = Color.FromArgb(255, 192, 255);
            guna2GradientButton1.FillColor2 = Color.FromArgb(239, 139, 106);
            guna2GradientButton1.Font = new Font("Microsoft Sans Serif", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2GradientButton1.ForeColor = Color.MidnightBlue;
            guna2GradientButton1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            guna2GradientButton1.Image = (Image)resources.GetObject("guna2GradientButton1.Image");
            guna2GradientButton1.ImageSize = new Size(60, 60);
            guna2GradientButton1.Location = new Point(429, 215);
            guna2GradientButton1.Margin = new Padding(3, 4, 3, 4);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2GradientButton1.Size = new Size(311, 125);
            guna2GradientButton1.TabIndex = 34;
            guna2GradientButton1.Text = "Pay Bills";
            guna2GradientButton1.Click += guna2GradientButton1_Click;
            // 
            // btnDeposit
            // 
            btnDeposit.CustomizableEdges = customizableEdges6;
            btnDeposit.DisabledState.BorderColor = Color.DarkGray;
            btnDeposit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDeposit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDeposit.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btnDeposit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDeposit.FillColor = Color.FromArgb(255, 255, 128);
            btnDeposit.FillColor2 = Color.FromArgb(239, 139, 106);
            btnDeposit.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDeposit.ForeColor = Color.MidnightBlue;
            btnDeposit.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            btnDeposit.Image = (Image)resources.GetObject("btnDeposit.Image");
            btnDeposit.ImageOffset = new Point(-6, 0);
            btnDeposit.ImageSize = new Size(60, 60);
            btnDeposit.Location = new Point(112, 82);
            btnDeposit.Margin = new Padding(3, 4, 3, 4);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.ShadowDecoration.CustomizableEdges = customizableEdges7;
            btnDeposit.Size = new Size(311, 125);
            btnDeposit.TabIndex = 33;
            btnDeposit.Text = "Deposit";
            btnDeposit.TextOffset = new Point(-3, 3);
            btnDeposit.Click += btnbal_Click;
            // 
            // btnWithdraw
            // 
            btnWithdraw.CustomizableEdges = customizableEdges8;
            btnWithdraw.DisabledState.BorderColor = Color.DarkGray;
            btnWithdraw.DisabledState.CustomBorderColor = Color.DarkGray;
            btnWithdraw.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnWithdraw.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            btnWithdraw.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnWithdraw.FillColor = Color.FromArgb(255, 192, 255);
            btnWithdraw.FillColor2 = Color.FromArgb(192, 0, 192);
            btnWithdraw.Font = new Font("Microsoft Sans Serif", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnWithdraw.ForeColor = Color.MidnightBlue;
            btnWithdraw.Image = (Image)resources.GetObject("btnWithdraw.Image");
            btnWithdraw.ImageSize = new Size(60, 60);
            btnWithdraw.Location = new Point(112, 215);
            btnWithdraw.Margin = new Padding(3, 4, 3, 4);
            btnWithdraw.Name = "btnWithdraw";
            btnWithdraw.ShadowDecoration.CustomizableEdges = customizableEdges9;
            btnWithdraw.Size = new Size(311, 125);
            btnWithdraw.TabIndex = 32;
            btnWithdraw.Text = "Withdraw";
            btnWithdraw.Click += btnWithdraw_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(621, 360);
            label5.Name = "label5";
            label5.Size = new Size(152, 28);
            label5.TabIndex = 31;
            label5.Text = "FundTastic";
            // 
            // guna2Button5
            // 
            guna2Button5.BorderRadius = 20;
            guna2Button5.CustomizableEdges = customizableEdges10;
            guna2Button5.DisabledState.BorderColor = Color.DarkGray;
            guna2Button5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button5.FillColor = Color.Brown;
            guna2Button5.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button5.ForeColor = Color.White;
            guna2Button5.Location = new Point(318, 347);
            guna2Button5.Name = "guna2Button5";
            guna2Button5.ShadowDecoration.CustomizableEdges = customizableEdges11;
            guna2Button5.Size = new Size(213, 51);
            guna2Button5.TabIndex = 6;
            guna2Button5.Text = "Eject Card";
            guna2Button5.Click += guna2Button5_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(823, 411);
            Controls.Add(guna2GradientPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2GradientButton btnWithdraw;
        private Guna.UI2.WinForms.Guna2GradientButton btnDeposit;
        private Guna.UI2.WinForms.Guna2GradientButton btnbal;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes1;
        private Label label1;
        private Label label5;
    }
}