﻿namespace atm2
{
    partial class checkbalance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            guna2Button9 = new Guna.UI2.WinForms.Guna2Button();
            guna2Shapes1 = new Guna.UI2.WinForms.Guna2Shapes();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            txtboxBal = new Guna.UI2.WinForms.Guna2HtmlLabel();
            label1 = new Label();
            label5 = new Label();
            guna2GradientPanel1.SuspendLayout();
            guna2CustomGradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Transparent;
            guna2GradientPanel1.Controls.Add(guna2Button9);
            guna2GradientPanel1.Controls.Add(guna2Shapes1);
            guna2GradientPanel1.Controls.Add(guna2CustomGradientPanel1);
            guna2GradientPanel1.Controls.Add(label5);
            guna2GradientPanel1.CustomizableEdges = customizableEdges6;
            guna2GradientPanel1.FillColor = Color.Purple;
            guna2GradientPanel1.FillColor2 = Color.FromArgb(77, 67, 118);
            guna2GradientPanel1.ForeColor = Color.Transparent;
            guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            guna2GradientPanel1.Location = new Point(-8, 0);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2GradientPanel1.Size = new Size(850, 424);
            guna2GradientPanel1.TabIndex = 5;
            // 
            // guna2Button9
            // 
            guna2Button9.BackColor = Color.Transparent;
            guna2Button9.BorderRadius = 16;
            guna2Button9.CustomizableEdges = customizableEdges1;
            guna2Button9.DisabledState.BorderColor = Color.DarkGray;
            guna2Button9.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button9.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button9.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button9.FillColor = Color.FromArgb(255, 128, 128);
            guna2Button9.Font = new Font("Segoe UI Historic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button9.ForeColor = Color.Black;
            guna2Button9.Location = new Point(560, 303);
            guna2Button9.Name = "guna2Button9";
            guna2Button9.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2Button9.Size = new Size(174, 45);
            guna2Button9.TabIndex = 64;
            guna2Button9.Text = "Cancel";
            guna2Button9.Click += guna2Button9_Click;
            // 
            // guna2Shapes1
            // 
            guna2Shapes1.BackColor = Color.Transparent;
            guna2Shapes1.BorderColor = Color.Transparent;
            guna2Shapes1.FillColor = Color.White;
            guna2Shapes1.ForeColor = Color.Transparent;
            guna2Shapes1.LineThickness = 2;
            guna2Shapes1.Location = new Point(-32, 75);
            guna2Shapes1.Margin = new Padding(3, 4, 3, 4);
            guna2Shapes1.Name = "guna2Shapes1";
            guna2Shapes1.PolygonSkip = 1;
            guna2Shapes1.Rotate = 0F;
            guna2Shapes1.RoundedEdges = customizableEdges3;
            guna2Shapes1.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            guna2Shapes1.Size = new Size(898, 17);
            guna2Shapes1.TabIndex = 63;
            guna2Shapes1.Text = "guna2Shapes1";
            guna2Shapes1.Zoom = 80;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.BackColor = Color.Transparent;
            guna2CustomGradientPanel1.BorderRadius = 16;
            guna2CustomGradientPanel1.Controls.Add(txtboxBal);
            guna2CustomGradientPanel1.Controls.Add(label1);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges4;
            guna2CustomGradientPanel1.FillColor = Color.Plum;
            guna2CustomGradientPanel1.FillColor2 = Color.Plum;
            guna2CustomGradientPanel1.FillColor3 = Color.Plum;
            guna2CustomGradientPanel1.FillColor4 = Color.Plum;
            guna2CustomGradientPanel1.Location = new Point(102, 121);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2CustomGradientPanel1.Size = new Size(633, 176);
            guna2CustomGradientPanel1.TabIndex = 62;
            // 
            // txtboxBal
            // 
            txtboxBal.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtboxBal.BackColor = Color.Transparent;
            txtboxBal.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtboxBal.ForeColor = Color.Black;
            txtboxBal.Location = new Point(272, 76);
            txtboxBal.Margin = new Padding(3, 4, 3, 4);
            txtboxBal.Name = "txtboxBal";
            txtboxBal.Size = new Size(69, 38);
            txtboxBal.TabIndex = 62;
            txtboxBal.Text = "------";
            txtboxBal.TextAlignment = ContentAlignment.MiddleCenter;
            txtboxBal.Click += guna2HtmlLabel1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(208, 23);
            label1.Name = "label1";
            label1.Size = new Size(233, 31);
            label1.TabIndex = 59;
            label1.Text = "Account Balance";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Verdana", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(51, 36);
            label5.Name = "label5";
            label5.Size = new Size(187, 34);
            label5.TabIndex = 58;
            label5.Text = "FundTastic";
            // 
            // checkbalance
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(834, 415);
            Controls.Add(guna2GradientPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "checkbalance";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "checkbalance";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Label label1;
        private Label label5;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel txtboxBal;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes1;
        private Guna.UI2.WinForms.Guna2Button guna2Button9;
    }
}