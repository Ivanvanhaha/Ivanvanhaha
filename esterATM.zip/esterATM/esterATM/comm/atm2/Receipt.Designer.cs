﻿namespace atm2
{
    partial class Receipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Receipt));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            txtCompany = new Guna.UI2.WinForms.Guna2HtmlLabel();
            txtissuer = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2Shapes1 = new Guna.UI2.WinForms.Guna2Shapes();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2GradientPanel1.SuspendLayout();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.Controls.Add(guna2Panel1);
            guna2GradientPanel1.CustomizableEdges = customizableEdges5;
            guna2GradientPanel1.FillColor = Color.Purple;
            guna2GradientPanel1.FillColor2 = Color.FromArgb(77, 67, 118);
            guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            guna2GradientPanel1.Location = new Point(-2, -3);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2GradientPanel1.Size = new Size(503, 618);
            guna2GradientPanel1.TabIndex = 3;
            guna2GradientPanel1.Paint += guna2GradientPanel1_Paint;
            // 
            // guna2Panel1
            // 
            guna2Panel1.Controls.Add(guna2HtmlLabel8);
            guna2Panel1.Controls.Add(guna2HtmlLabel7);
            guna2Panel1.Controls.Add(txtCompany);
            guna2Panel1.Controls.Add(txtissuer);
            guna2Panel1.Controls.Add(guna2HtmlLabel6);
            guna2Panel1.Controls.Add(guna2HtmlLabel5);
            guna2Panel1.Controls.Add(guna2HtmlLabel4);
            guna2Panel1.Controls.Add(guna2HtmlLabel3);
            guna2Panel1.Controls.Add(guna2HtmlLabel2);
            guna2Panel1.Controls.Add(guna2HtmlLabel1);
            guna2Panel1.Controls.Add(guna2Shapes1);
            guna2Panel1.Controls.Add(guna2CirclePictureBox1);
            guna2Panel1.CustomizableEdges = customizableEdges3;
            guna2Panel1.Location = new Point(15, 32);
            guna2Panel1.Margin = new Padding(3, 4, 3, 4);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2Panel1.Size = new Size(453, 541);
            guna2Panel1.TabIndex = 0;
            guna2Panel1.Paint += guna2Panel1_Paint;
            // 
            // txtCompany
            // 
            txtCompany.AutoSize = false;
            txtCompany.AutoSizeHeightOnly = true;
            txtCompany.BackColor = Color.Transparent;
            txtCompany.Font = new Font("Segoe UI", 11.25F);
            txtCompany.Location = new Point(278, 333);
            txtCompany.Margin = new Padding(3, 4, 3, 4);
            txtCompany.Name = "txtCompany";
            txtCompany.Size = new Size(162, 51);
            txtCompany.TabIndex = 45;
            txtCompany.Text = "-----------------------";
            txtCompany.Click += txtCompany_Click;
            // 
            // txtissuer
            // 
            txtissuer.BackColor = Color.Transparent;
            txtissuer.Font = new Font("Segoe UI", 11.25F);
            txtissuer.Location = new Point(35, 346);
            txtissuer.Margin = new Padding(3, 4, 3, 4);
            txtissuer.Name = "txtissuer";
            txtissuer.Size = new Size(59, 27);
            txtissuer.TabIndex = 44;
            txtissuer.Text = "-------";
            txtissuer.TextAlignment = ContentAlignment.MiddleCenter;
            txtissuer.Click += txtissuer_Click;
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel6.Location = new Point(279, 295);
            guna2HtmlLabel6.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(59, 27);
            guna2HtmlLabel6.TabIndex = 43;
            guna2HtmlLabel6.Text = "-------";
            guna2HtmlLabel6.TextAlignment = ContentAlignment.MiddleCenter;
            guna2HtmlLabel6.Click += guna2HtmlLabel6_Click;
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel5.Location = new Point(279, 256);
            guna2HtmlLabel5.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(59, 27);
            guna2HtmlLabel5.TabIndex = 42;
            guna2HtmlLabel5.Text = "-------";
            guna2HtmlLabel5.TextAlignment = ContentAlignment.MiddleCenter;
            guna2HtmlLabel5.Click += guna2HtmlLabel5_Click;
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2HtmlLabel4.Location = new Point(133, 472);
            guna2HtmlLabel4.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(195, 27);
            guna2HtmlLabel4.TabIndex = 41;
            guna2HtmlLabel4.Text = "------------------------";
            guna2HtmlLabel4.TextAlignment = ContentAlignment.MiddleCenter;
            guna2HtmlLabel4.Click += guna2HtmlLabel4_Click;
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel3.Location = new Point(35, 295);
            guna2HtmlLabel3.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(147, 27);
            guna2HtmlLabel3.TabIndex = 40;
            guna2HtmlLabel3.Text = "Current Balance :";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel2.Location = new Point(35, 244);
            guna2HtmlLabel2.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(170, 27);
            guna2HtmlLabel2.TabIndex = 39;
            guna2HtmlLabel2.Text = "Account Withdrawn";
            guna2HtmlLabel2.Click += guna2HtmlLabel2_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel1.Location = new Point(279, 175);
            guna2HtmlLabel1.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(89, 27);
            guna2HtmlLabel1.TabIndex = 38;
            guna2HtmlLabel1.Text = "*******633";
            // 
            // guna2Shapes1
            // 
            guna2Shapes1.BackColor = Color.Transparent;
            guna2Shapes1.BorderColor = Color.Transparent;
            guna2Shapes1.FillColor = Color.MidnightBlue;
            guna2Shapes1.ForeColor = Color.Transparent;
            guna2Shapes1.LineThickness = 2;
            guna2Shapes1.Location = new Point(-18, 210);
            guna2Shapes1.Margin = new Padding(3, 4, 3, 4);
            guna2Shapes1.Name = "guna2Shapes1";
            guna2Shapes1.PolygonSkip = 1;
            guna2Shapes1.Rotate = 0F;
            guna2Shapes1.RoundedEdges = customizableEdges1;
            guna2Shapes1.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            guna2Shapes1.Size = new Size(503, 17);
            guna2Shapes1.TabIndex = 37;
            guna2Shapes1.Text = "guna2Shapes1";
            guna2Shapes1.Zoom = 80;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(190, 19);
            guna2CirclePictureBox1.Margin = new Padding(3, 4, 3, 4);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(93, 92);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2CirclePictureBox1.TabIndex = 0;
            guna2CirclePictureBox1.TabStop = false;
            guna2CirclePictureBox1.Click += guna2CirclePictureBox1_Click;
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel7.Location = new Point(164, 119);
            guna2HtmlLabel7.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(151, 27);
            guna2HtmlLabel7.TabIndex = 46;
            guna2HtmlLabel7.Text = "Payment Success!";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 11.25F);
            guna2HtmlLabel8.Location = new Point(35, 175);
            guna2HtmlLabel8.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(155, 27);
            guna2HtmlLabel8.TabIndex = 47;
            guna2HtmlLabel8.Text = "Account Number : ";
            // 
            // Receipt
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(479, 597);
            Controls.Add(guna2GradientPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "Receipt";
            Text = "Receipt";
            guna2GradientPanel1.ResumeLayout(false);
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel txtissuer;
        private Guna.UI2.WinForms.Guna2HtmlLabel txtCompany;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
    }
}