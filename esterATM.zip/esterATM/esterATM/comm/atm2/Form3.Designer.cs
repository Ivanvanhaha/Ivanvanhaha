﻿namespace atm2
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            label1 = new Label();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2CircleButton12 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton11 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton10 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton7 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton8 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton9 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton4 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton5 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton6 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton3 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            label2 = new Label();
            guna2GradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.Controls.Add(label2);
            guna2GradientPanel1.Controls.Add(label1);
            guna2GradientPanel1.Controls.Add(guna2TextBox1);
            guna2GradientPanel1.Controls.Add(guna2CircleButton12);
            guna2GradientPanel1.Controls.Add(guna2CircleButton11);
            guna2GradientPanel1.Controls.Add(guna2CircleButton10);
            guna2GradientPanel1.Controls.Add(guna2CircleButton7);
            guna2GradientPanel1.Controls.Add(guna2CircleButton8);
            guna2GradientPanel1.Controls.Add(guna2CircleButton9);
            guna2GradientPanel1.Controls.Add(guna2CircleButton4);
            guna2GradientPanel1.Controls.Add(guna2CircleButton5);
            guna2GradientPanel1.Controls.Add(guna2CircleButton6);
            guna2GradientPanel1.Controls.Add(guna2CircleButton3);
            guna2GradientPanel1.Controls.Add(guna2CircleButton2);
            guna2GradientPanel1.Controls.Add(guna2CircleButton1);
            guna2GradientPanel1.CustomizableEdges = customizableEdges15;
            guna2GradientPanel1.FillColor = Color.Purple;
            guna2GradientPanel1.FillColor2 = Color.FromArgb(77, 67, 118);
            guna2GradientPanel1.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            guna2GradientPanel1.Location = new Point(-1, -1);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges16;
            guna2GradientPanel1.Size = new Size(483, 588);
            guna2GradientPanel1.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(56, 28);
            label1.Name = "label1";
            label1.Size = new Size(306, 53);
            label1.TabIndex = 30;
            label1.Text = "FundTastic ";
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.BackColor = Color.Transparent;
            guna2TextBox1.BorderColor = Color.Transparent;
            guna2TextBox1.BorderRadius = 20;
            guna2TextBox1.CustomizableEdges = customizableEdges1;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FillColor = Color.DarkGray;
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            guna2TextBox1.ForeColor = Color.Black;
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(56, 126);
            guna2TextBox1.Margin = new Padding(5);
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PasswordChar = '\0';
            guna2TextBox1.PlaceholderForeColor = Color.Gray;
            guna2TextBox1.PlaceholderText = "";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2TextBox1.Size = new Size(383, 60);
            guna2TextBox1.TabIndex = 29;
            guna2TextBox1.TextAlign = HorizontalAlignment.Center;
            guna2TextBox1.TextChanged += guna2TextBox1_TextChanged;
            // 
            // guna2CircleButton12
            // 
            guna2CircleButton12.BackColor = Color.Transparent;
            guna2CircleButton12.BorderColor = Color.Transparent;
            guna2CircleButton12.BorderThickness = 3;
            guna2CircleButton12.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton12.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton12.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton12.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton12.FillColor = Color.LimeGreen;
            guna2CircleButton12.Font = new Font("Segoe UI", 9F);
            guna2CircleButton12.ForeColor = Color.Purple;
            guna2CircleButton12.Image = (Image)resources.GetObject("guna2CircleButton12.Image");
            guna2CircleButton12.ImageSize = new Size(26, 26);
            guna2CircleButton12.Location = new Point(296, 469);
            guna2CircleButton12.Name = "guna2CircleButton12";
            guna2CircleButton12.PressedColor = Color.White;
            guna2CircleButton12.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2CircleButton12.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton12.Size = new Size(77, 75);
            guna2CircleButton12.TabIndex = 28;
            guna2CircleButton12.Click += guna2CircleButton12_Click;
            // 
            // guna2CircleButton11
            // 
            guna2CircleButton11.BackColor = Color.Transparent;
            guna2CircleButton11.BorderColor = Color.Transparent;
            guna2CircleButton11.BorderThickness = 3;
            guna2CircleButton11.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton11.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton11.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton11.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton11.FillColor = Color.IndianRed;
            guna2CircleButton11.Font = new Font("Segoe UI", 9F);
            guna2CircleButton11.ForeColor = Color.Purple;
            guna2CircleButton11.Image = (Image)resources.GetObject("guna2CircleButton11.Image");
            guna2CircleButton11.ImageSize = new Size(26, 26);
            guna2CircleButton11.Location = new Point(95, 468);
            guna2CircleButton11.Name = "guna2CircleButton11";
            guna2CircleButton11.PressedColor = Color.Purple;
            guna2CircleButton11.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2CircleButton11.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton11.Size = new Size(77, 75);
            guna2CircleButton11.TabIndex = 27;
            guna2CircleButton11.Click += guna2CircleButton11_Click;
            // 
            // guna2CircleButton10
            // 
            guna2CircleButton10.BackColor = Color.Transparent;
            guna2CircleButton10.BorderColor = Color.Transparent;
            guna2CircleButton10.BorderThickness = 3;
            guna2CircleButton10.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton10.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton10.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton10.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton10.FillColor = Color.DarkGray;
            guna2CircleButton10.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton10.ForeColor = Color.Black;
            guna2CircleButton10.Location = new Point(194, 468);
            guna2CircleButton10.Name = "guna2CircleButton10";
            guna2CircleButton10.PressedColor = Color.White;
            guna2CircleButton10.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2CircleButton10.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton10.Size = new Size(77, 75);
            guna2CircleButton10.TabIndex = 26;
            guna2CircleButton10.Text = "0";
            guna2CircleButton10.Click += guna2CircleButton10_Click;
            // 
            // guna2CircleButton7
            // 
            guna2CircleButton7.BackColor = Color.Transparent;
            guna2CircleButton7.BorderColor = Color.Transparent;
            guna2CircleButton7.BorderThickness = 3;
            guna2CircleButton7.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton7.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton7.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton7.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton7.FillColor = Color.DarkGray;
            guna2CircleButton7.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton7.ForeColor = Color.Black;
            guna2CircleButton7.Location = new Point(296, 389);
            guna2CircleButton7.Name = "guna2CircleButton7";
            guna2CircleButton7.PressedColor = Color.LightGray;
            guna2CircleButton7.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2CircleButton7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton7.Size = new Size(77, 75);
            guna2CircleButton7.TabIndex = 25;
            guna2CircleButton7.Text = "9";
            guna2CircleButton7.Click += guna2CircleButton7_Click;
            // 
            // guna2CircleButton8
            // 
            guna2CircleButton8.BackColor = Color.Transparent;
            guna2CircleButton8.BorderColor = Color.Transparent;
            guna2CircleButton8.BorderThickness = 3;
            guna2CircleButton8.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton8.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton8.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton8.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton8.FillColor = Color.DarkGray;
            guna2CircleButton8.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton8.ForeColor = Color.Black;
            guna2CircleButton8.Location = new Point(296, 309);
            guna2CircleButton8.Name = "guna2CircleButton8";
            guna2CircleButton8.PressedColor = Color.LightGray;
            guna2CircleButton8.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2CircleButton8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton8.Size = new Size(77, 75);
            guna2CircleButton8.TabIndex = 24;
            guna2CircleButton8.Text = "6";
            guna2CircleButton8.Click += guna2CircleButton8_Click;
            // 
            // guna2CircleButton9
            // 
            guna2CircleButton9.BackColor = Color.Transparent;
            guna2CircleButton9.BorderColor = Color.Transparent;
            guna2CircleButton9.BorderThickness = 3;
            guna2CircleButton9.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton9.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton9.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton9.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton9.FillColor = Color.DarkGray;
            guna2CircleButton9.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton9.ForeColor = Color.Black;
            guna2CircleButton9.Location = new Point(296, 229);
            guna2CircleButton9.Name = "guna2CircleButton9";
            guna2CircleButton9.PressedColor = Color.LightGray;
            guna2CircleButton9.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2CircleButton9.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton9.Size = new Size(77, 75);
            guna2CircleButton9.TabIndex = 23;
            guna2CircleButton9.Text = "3";
            guna2CircleButton9.Click += guna2CircleButton9_Click;
            // 
            // guna2CircleButton4
            // 
            guna2CircleButton4.BackColor = Color.Transparent;
            guna2CircleButton4.BorderColor = Color.Transparent;
            guna2CircleButton4.BorderThickness = 3;
            guna2CircleButton4.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton4.FillColor = Color.DarkGray;
            guna2CircleButton4.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton4.ForeColor = Color.Black;
            guna2CircleButton4.Location = new Point(194, 388);
            guna2CircleButton4.Name = "guna2CircleButton4";
            guna2CircleButton4.PressedColor = Color.LightGray;
            guna2CircleButton4.ShadowDecoration.CustomizableEdges = customizableEdges9;
            guna2CircleButton4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton4.Size = new Size(77, 75);
            guna2CircleButton4.TabIndex = 22;
            guna2CircleButton4.Text = "8";
            guna2CircleButton4.Click += guna2CircleButton4_Click;
            // 
            // guna2CircleButton5
            // 
            guna2CircleButton5.BackColor = Color.Transparent;
            guna2CircleButton5.BorderColor = Color.Transparent;
            guna2CircleButton5.BorderThickness = 3;
            guna2CircleButton5.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton5.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton5.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton5.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton5.FillColor = Color.DarkGray;
            guna2CircleButton5.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton5.ForeColor = Color.Black;
            guna2CircleButton5.Location = new Point(194, 308);
            guna2CircleButton5.Name = "guna2CircleButton5";
            guna2CircleButton5.PressedColor = Color.LightGray;
            guna2CircleButton5.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2CircleButton5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton5.Size = new Size(77, 75);
            guna2CircleButton5.TabIndex = 21;
            guna2CircleButton5.Text = "5";
            guna2CircleButton5.Click += guna2CircleButton5_Click;
            // 
            // guna2CircleButton6
            // 
            guna2CircleButton6.BackColor = Color.Transparent;
            guna2CircleButton6.BorderColor = Color.Transparent;
            guna2CircleButton6.BorderThickness = 3;
            guna2CircleButton6.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton6.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton6.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton6.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton6.FillColor = Color.DarkGray;
            guna2CircleButton6.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton6.ForeColor = Color.Black;
            guna2CircleButton6.Location = new Point(194, 228);
            guna2CircleButton6.Name = "guna2CircleButton6";
            guna2CircleButton6.PressedColor = Color.LightGray;
            guna2CircleButton6.ShadowDecoration.CustomizableEdges = customizableEdges11;
            guna2CircleButton6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton6.Size = new Size(77, 75);
            guna2CircleButton6.TabIndex = 20;
            guna2CircleButton6.Text = "2";
            guna2CircleButton6.Click += guna2CircleButton6_Click;
            // 
            // guna2CircleButton3
            // 
            guna2CircleButton3.BackColor = Color.Transparent;
            guna2CircleButton3.BorderColor = Color.Transparent;
            guna2CircleButton3.BorderThickness = 3;
            guna2CircleButton3.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton3.FillColor = Color.DarkGray;
            guna2CircleButton3.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton3.ForeColor = Color.Black;
            guna2CircleButton3.Location = new Point(95, 388);
            guna2CircleButton3.Name = "guna2CircleButton3";
            guna2CircleButton3.PressedColor = Color.LightGray;
            guna2CircleButton3.ShadowDecoration.CustomizableEdges = customizableEdges12;
            guna2CircleButton3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton3.Size = new Size(77, 75);
            guna2CircleButton3.TabIndex = 19;
            guna2CircleButton3.Text = "7";
            guna2CircleButton3.Click += guna2CircleButton3_Click;
            // 
            // guna2CircleButton2
            // 
            guna2CircleButton2.BackColor = Color.Transparent;
            guna2CircleButton2.BorderColor = Color.Transparent;
            guna2CircleButton2.BorderThickness = 3;
            guna2CircleButton2.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton2.FillColor = Color.DarkGray;
            guna2CircleButton2.Font = new Font("Calibri", 16.2F, FontStyle.Bold);
            guna2CircleButton2.ForeColor = Color.Black;
            guna2CircleButton2.Location = new Point(95, 309);
            guna2CircleButton2.Name = "guna2CircleButton2";
            guna2CircleButton2.PressedColor = Color.LightGray;
            guna2CircleButton2.ShadowDecoration.CustomizableEdges = customizableEdges13;
            guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton2.Size = new Size(77, 75);
            guna2CircleButton2.TabIndex = 18;
            guna2CircleButton2.Text = "4";
            guna2CircleButton2.Click += guna2CircleButton2_Click;
            // 
            // guna2CircleButton1
            // 
            guna2CircleButton1.BackColor = Color.Transparent;
            guna2CircleButton1.BorderColor = Color.Transparent;
            guna2CircleButton1.BorderThickness = 3;
            guna2CircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2CircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2CircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2CircleButton1.FillColor = Color.DarkGray;
            guna2CircleButton1.Font = new Font("Calibri", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2CircleButton1.ForeColor = Color.Black;
            guna2CircleButton1.Location = new Point(95, 228);
            guna2CircleButton1.Name = "guna2CircleButton1";
            guna2CircleButton1.PressedColor = Color.LightGray;
            guna2CircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CircleButton1.Size = new Size(77, 75);
            guna2CircleButton1.TabIndex = 17;
            guna2CircleButton1.Text = "1";
            guna2CircleButton1.Click += guna2CircleButton1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(335, 28);
            label2.Name = "label2";
            label2.Size = new Size(50, 20);
            label2.TabIndex = 31;
            label2.Text = "ATM";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(483, 587);
            Controls.Add(guna2GradientPanel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form3";
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton12;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton11;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton10;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton7;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton8;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton9;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton4;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton5;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton6;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Label label2;
    }
}