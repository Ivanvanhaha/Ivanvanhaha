﻿using System;

public static class Balance
{
    int balance = 100000;
}
