﻿using System;

public static class GlobalVariables
{
    
    public static int GlobalIntVariable = 0;
    
}
